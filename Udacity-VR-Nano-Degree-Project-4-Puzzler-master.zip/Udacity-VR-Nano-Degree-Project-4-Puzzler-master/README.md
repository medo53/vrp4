# Udacity-VR-Nano-Degree-Project-4-Puzzler
Puzzler is a mobile VR game targeted at new VR users, that challenges a player by testing their memory with "Simon-Says" style puzzles. This application deploys to an Android device.

#### Interested to see how this project was made?

Visit my website: www.davidhaley.io

# Puzzler VR

### Screenshots

![alt text](https://cloud.githubusercontent.com/assets/11729897/22602661/5cd163d6-ea01-11e6-8f0f-a220b15ab342.png)
![alt text](https://cloud.githubusercontent.com/assets/11729897/22602649/52d7e472-ea01-11e6-89d8-ecc0d1df0c87.png)
![alt text](https://cloud.githubusercontent.com/assets/11729897/22602663/5e4758ec-ea01-11e6-923f-e1eedd1ab122.png)
![alt text](https://cloud.githubusercontent.com/assets/11729897/22602665/5f7a1498-ea01-11e6-8a8c-b062c87133f5.png)
![alt text](https://cloud.githubusercontent.com/assets/11729897/22602666/608d18da-ea01-11e6-9914-1797d1344a01.png)

